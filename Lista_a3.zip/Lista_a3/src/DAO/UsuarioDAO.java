package DAO;

import Armazenamentoid.ArmazenarId;
import DTO.UsuarioDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 * Classe para manipulação de dados do usuário no banco de dados.
 */
public class UsuarioDAO {

    Connection conn;
    PreparedStatement pstm;

    /**
     * Autentica um usuário no sistema.
     *
     * @param username Nome de usuário.
     * @param password Senha de usuário.
     * @return true se a autenticação for bem-sucedida, caso contrário, false.
     */
    public ResultSet autenticarUsuario(UsuarioDTO objusuariodto) {
        ResultSet rs = null;
        try {
            conn = new ConexaoDAO().conectaBD();
            String sql = "SELECT * FROM pessoa WHERE nome = ? AND senha = ?";
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objusuariodto.getNome_usuario());
            pstm.setString(2, objusuariodto.getSenha_usuario());
           
            rs = pstm.executeQuery();
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Erro ao autenticar usuário: " + erro);
        }
        return rs;
    }

    /**
     * Realiza o cadastro de um novo usuário no sistema.
     *
     * @param objusuariodto Objeto contendo os dados do usuário a ser
     * cadastrado.
     */
    public void cadastrarUsuario(UsuarioDTO objusuariodto) {
        String sql = "INSERT INTO pessoa (nome, senha) VALUES (?, ?)";
        conn = new ConexaoDAO().conectaBD();

        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objusuariodto.getNome_usuario());
            pstm.setString(2, objusuariodto.getSenha_usuario());
            pstm.executeUpdate();
            JOptionPane.showMessageDialog(null, "Usuário cadastrado com sucesso");
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar usuário: " + erro);
        }
    }

    public void AlterarUsuario(UsuarioDTO objusuariodto) {
          
        
        String sql = "UPDATE pessoa SET nome = ?, senha = ? WHERE id = ?";
        conn = new ConexaoDAO().conectaBD();
        
        try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objusuariodto.getNome_usuario());
            pstm.setString(2, objusuariodto.getSenha_usuario());
            pstm.setInt(3, objusuariodto.getId_usuario());
            pstm.executeUpdate();
            JOptionPane.showMessageDialog(null, "Usuário alterado com sucesso");
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar usuário: " + erro);
        }
    }
    
    public void DeletarUsuario(UsuarioDTO objusuariodto) {
    String sql = "DELETE FROM pessoa WHERE id = ?";
    conn = new ConexaoDAO().conectaBD();

    try {
        pstm = conn.prepareStatement(sql);
        pstm.setInt(1, objusuariodto.getId_usuario());
        pstm.executeUpdate();
        JOptionPane.showMessageDialog(null, "Usuário deletado");
    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(null, "Erro ao deletar usuário: " + erro);
    }
}
}
