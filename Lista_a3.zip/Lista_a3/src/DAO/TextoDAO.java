/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Armazenamentoid.ArmazenarId;
import DTO.TextoDTO;
import DTO.UsuarioDTO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author kauat
 */
public class TextoDAO {

    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<TextoDTO> lista = new ArrayList<>();

    public void TextoUsuario(TextoDTO objtextodto) {
        String sqlInsert = "INSERT INTO Texto (Texto, id_pessoa, data) VALUES (?, ?, ?)";
        conn = new ConexaoDAO().conectaBD();

        try {
            conn.setAutoCommit(false);

            pstm = conn.prepareStatement(sqlInsert);
            pstm.setString(1, objtextodto.getTexto_usuario());
            pstm.setInt(2, ArmazenarId.getUserId());
            // Convertendo java.util.Date para java.sql.Date
            pstm.setDate(3, new java.sql.Date(objtextodto.getData_usuario().getTime()));
            pstm.executeUpdate();

            conn.commit();
            JOptionPane.showMessageDialog(null, "Texto adicionado");
        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir texto: Texto ou Data Não adicionados" + "\n" + erro);
        }
    }

    public ArrayList<TextoDTO> PesquisarTexto() {

        String sql = "SELECT * FROM Texto WHERE id_pessoa = ?";

        try {
            conn = new ConexaoDAO().conectaBD();
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, ArmazenarId.getUserId());
            rs = pstm.executeQuery();

            while (rs.next()) {
                TextoDTO objtextoDTO = new TextoDTO();
                objtextoDTO.setId_texto(rs.getInt("idTexto"));
                objtextoDTO.setTexto_usuario(rs.getString("Texto"));
                objtextoDTO.setData_usuario(rs.getDate("data"));

                lista.add(objtextoDTO);
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Pesquisa de Texto : " + erro);
        }
        return lista;
    }

    public void DeletarTexto(TextoDTO objtextodto) {
        String sql = "DELETE FROM Texto WHERE idTexto = ?";
        conn = new ConexaoDAO().conectaBD();

        try {
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, objtextodto.getId_texto());
            pstm.executeUpdate();
            JOptionPane.showMessageDialog(null, "Texto deletado");
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Erro Texto usuário: " + erro);
        }
    }
}
