/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.util.Date;

/**
 *
 * @author kauat
 */
public class TextoDTO {

    private int id_texto;
    private java.util.Date data_usuario;
    private Float prazo_usuario;
    private String texto_usuario;

    public int getId_texto() {
        return id_texto;
    }

    public void setId_texto(int id_texto) {
        this.id_texto = id_texto;
    }

    public Date getData_usuario() {
        return data_usuario;
    }

    public void setData_usuario(Date data_usuario) {
        this.data_usuario = data_usuario;
    }

    public Float getPrazo_usuario() {
        return prazo_usuario;
    }

    public void setPrazo_usuario(Float prazo_usuario) {
        this.prazo_usuario = prazo_usuario;
    }

    public String getTexto_usuario() {
        return texto_usuario;
    }

    public void setTexto_usuario(String texto_usuario) {
        this.texto_usuario = texto_usuario;
    }

}
